# CyberForce Full-Stack Website

A runnable cybersecurity services website with:
- Premium midnight-black / dark-blue / light-blue UI
- Animated 3D-style hero visual built with CSS (no external 3D asset required)
- Responsive public website
- Cybersecurity services loaded from SQLite
- Contact form stored in SQLite
- Officer/Admin login
- HTTP-only JWT session cookie
- Contact request management
- One-click WhatsApp actions
- Service management from Officer Dashboard
- Simulated SOC/threat telemetry clearly labeled as demo data

## Run locally

Requirements: Node.js 18+ recommended.

1. Install dependencies:
   `npm install`
2. Copy `.env.example` to `.env` and change `JWT_SECRET` and `ADMIN_PASSWORD`.
3. Start:
   `npm start`
4. Open:
   `http://localhost:3000`
5. Officer portal:
   `http://localhost:3000/officer`

Default demo credentials from `.env.example`:
- Email: `admin@cyberforce.local`
- Password: `ChangeMe123!`

Change these before deployment.

## WhatsApp

Primary contact:
+91 63069 27241

Direct chat:
https://wa.me/916306927241

## Production checklist

- Set a strong random JWT_SECRET.
- Set a strong ADMIN_PASSWORD.
- Run behind HTTPS.
- Use a managed database/backups for production.
- Add rate limiting / CAPTCHA to the public contact endpoint.
- Add CSRF protection if expanding cookie-authenticated state-changing endpoints.
- Configure secure cookie options for your deployment.
- Replace demo metrics, certifications and telemetry with verified/real data.
- Configure email/SMS/WhatsApp Business API notifications if required.
