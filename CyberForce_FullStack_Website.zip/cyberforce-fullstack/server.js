const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "dev-only-change-this-secret";
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@cyberforce.local";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "ChangeMe123!";

const db = new Database(path.join(__dirname, "cyberforce.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'super_admin',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS contacts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  company TEXT,
  phone TEXT,
  service TEXT,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'New',
  notes TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  icon TEXT DEFAULT 'shield',
  status TEXT NOT NULL DEFAULT 'Active',
  display_order INTEGER DEFAULT 0
);
`);

const admin = db.prepare("SELECT id FROM users WHERE email = ?").get(ADMIN_EMAIL);
if (!admin) {
  const hash = bcrypt.hashSync(ADMIN_PASSWORD, 12);
  db.prepare("INSERT INTO users (email,password_hash,role) VALUES (?,?,?)")
    .run(ADMIN_EMAIL, hash, "super_admin");
}

const serviceCount = db.prepare("SELECT COUNT(*) AS c FROM services").get().c;
if (!serviceCount) {
  const seed = db.prepare("INSERT INTO services (name,description,icon,display_order) VALUES (?,?,?,?)");
  [
    ["Cybersecurity Consulting","Security strategy, risk assessments and security architecture.","shield",1],
    ["Penetration Testing","Authorized testing to identify and validate security weaknesses.","bug",2],
    ["Vulnerability Assessment","Prioritized visibility into vulnerabilities across your attack surface.","scan",3],
    ["Managed Security Services","Continuous security support for modern organizations.","activity",4],
    ["Security Operations Center","24/7 monitoring and response workflows for security teams.","monitor",5],
    ["Cloud Security","Security controls and posture management for cloud environments.","cloud",6],
    ["Network Security","Protection, segmentation and monitoring for enterprise networks.","network",7],
    ["Incident Response","Structured investigation, containment and recovery support.","siren",8],
    ["Digital Forensics","Evidence-focused investigation and incident analysis.","search",9],
    ["Threat Intelligence","Actionable intelligence to understand and prioritize threats.","radar",10],
    ["Identity & Access Management","Strong authentication, authorization and access governance.","key",11],
    ["Security Awareness Training","Practical security education for teams and organizations.","users",12]
  ].forEach((x)=>seed.run(...x));
}

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:true}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

function auth(req,res,next){
  try{
    const token = req.cookies.cf_token;
    if(!token) return res.status(401).json({error:"Authentication required"});
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  }catch(e){ return res.status(401).json({error:"Invalid or expired session"}); }
}

app.post("/api/auth/login",(req,res)=>{
  const {email,password} = req.body || {};
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(String(email||"").trim().toLowerCase());
  if(!user || !bcrypt.compareSync(String(password||""), user.password_hash))
    return res.status(401).json({error:"Invalid email or password"});
  const token = jwt.sign({id:user.id,email:user.email,role:user.role}, JWT_SECRET, {expiresIn:"8h"});
  res.cookie("cf_token", token, {httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000});
  res.json({ok:true,user:{email:user.email,role:user.role}});
});

app.post("/api/auth/logout",(req,res)=>{ res.clearCookie("cf_token"); res.json({ok:true}); });
app.get("/api/auth/me",auth,(req,res)=>res.json({user:req.user}));

app.get("/api/services",(req,res)=>{
  res.json(db.prepare("SELECT * FROM services ORDER BY display_order,id").all());
});

app.post("/api/contact",(req,res)=>{
  const {name,email,company,phone,service,message} = req.body || {};
  if(!name || !email || !message) return res.status(400).json({error:"Name, email and message are required"});
  const info = db.prepare(`
    INSERT INTO contacts(name,email,company,phone,service,message)
    VALUES (?,?,?,?,?,?)
  `).run(
    String(name).trim(), String(email).trim(), String(company||"").trim(),
    String(phone||"").trim(), String(service||"").trim(), String(message).trim()
  );
  res.status(201).json({ok:true,id:info.lastInsertRowid});
});

app.get("/api/admin/stats",auth,(req,res)=>{
  const contacts = db.prepare("SELECT COUNT(*) c FROM contacts").get().c;
  const newContacts = db.prepare("SELECT COUNT(*) c FROM contacts WHERE status='New'").get().c;
  const inProgress = db.prepare("SELECT COUNT(*) c FROM contacts WHERE status='In Progress'").get().c;
  res.json({
    contacts,newContacts,inProgress,
    threatsBlocked:"98.7%",
    systemsMonitored:"24,680+",
    threatLevel:"LOW"
  });
});

app.get("/api/admin/contacts",auth,(req,res)=>{
  res.json(db.prepare("SELECT * FROM contacts ORDER BY id DESC").all());
});

app.patch("/api/admin/contacts/:id",auth,(req,res)=>{
  const {status,notes} = req.body || {};
  const allowed = ["New","Contacted","In Progress","Resolved","Archived"];
  if(status && !allowed.includes(status)) return res.status(400).json({error:"Invalid status"});
  const existing = db.prepare("SELECT * FROM contacts WHERE id=?").get(req.params.id);
  if(!existing) return res.status(404).json({error:"Contact not found"});
  db.prepare("UPDATE contacts SET status=?,notes=? WHERE id=?")
    .run(status || existing.status, notes ?? existing.notes, req.params.id);
  res.json({ok:true});
});

app.delete("/api/admin/contacts/:id",auth,(req,res)=>{
  db.prepare("DELETE FROM contacts WHERE id=?").run(req.params.id);
  res.json({ok:true});
});

app.get("/api/admin/services",auth,(req,res)=>{
  res.json(db.prepare("SELECT * FROM services ORDER BY display_order,id").all());
});

app.post("/api/admin/services",auth,(req,res)=>{
  const {name,description,icon,status,display_order} = req.body || {};
  if(!name || !description) return res.status(400).json({error:"Name and description are required"});
  const info = db.prepare("INSERT INTO services(name,description,icon,status,display_order) VALUES (?,?,?,?,?)")
    .run(name,description,icon||"shield",status||"Active",Number(display_order)||0);
  res.status(201).json({id:info.lastInsertRowid});
});

app.patch("/api/admin/services/:id",auth,(req,res)=>{
  const old = db.prepare("SELECT * FROM services WHERE id=?").get(req.params.id);
  if(!old) return res.status(404).json({error:"Service not found"});
  const x = req.body || {};
  db.prepare(`UPDATE services SET name=?,description=?,icon=?,status=?,display_order=? WHERE id=?`)
    .run(x.name??old.name,x.description??old.description,x.icon??old.icon,x.status??old.status,
         Number(x.display_order??old.display_order),req.params.id);
  res.json({ok:true});
});

app.delete("/api/admin/services/:id",auth,(req,res)=>{
  db.prepare("DELETE FROM services WHERE id=?").run(req.params.id);
  res.json({ok:true});
});

app.get("/officer", (req,res)=>res.sendFile(path.join(__dirname,"public","dashboard.html")));

app.listen(PORT,()=>console.log(`CyberForce running at http://localhost:${PORT}`));
